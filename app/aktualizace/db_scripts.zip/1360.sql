CREATE INDEX [stav] ON [epodatelna] ([stav]);
CREATE INDEX [odchozi] ON [epodatelna] ([odchozi]);
