ALTER TABLE [{tbls3}dokument] DROP COLUMN [md5_hash];
