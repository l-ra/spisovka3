
ALTER TABLE [epodatelna]
    CHANGE COLUMN [predmet] [predmet] varchar(260) NOT NULL DEFAULT '';