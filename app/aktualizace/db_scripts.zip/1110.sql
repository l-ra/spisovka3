ALTER TABLE [:PREFIX:epodatelna]
  DROP COLUMN [prijal_info];

