INSERT INTO [{tbls3}settings] VALUES ('spisovna_display_borrowed_documents', 'true');
