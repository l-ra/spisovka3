ALTER TABLE [{tbls3}dokument] CHANGE COLUMN [poradi] [poradi] smallint(6) NOT NULL DEFAULT '1';
