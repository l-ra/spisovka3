ALTER TABLE [:PREFIX:spis]
  CHANGE COLUMN [skartacni_znak] [skartacni_znak] ENUM('A','S','V') NULL,
  CHANGE COLUMN [skartacni_lhuta] [skartacni_lhuta] INT NULL;

