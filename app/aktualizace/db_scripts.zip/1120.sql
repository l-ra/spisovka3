
INSERT INTO [:PREFIX:settings] VALUES ('users_can_change_their_data', 'true');