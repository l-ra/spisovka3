-- Nedopatřením byl tento klíč definován dvakrát                  ;

ALTER TABLE `{tbls3}user_role` DROP KEY `user_role_code`;
