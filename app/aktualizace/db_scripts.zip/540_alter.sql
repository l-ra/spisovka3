------------------------;

ALTER TABLE `{tbls3}user_role` ADD UNIQUE `user_role_code` ( `code` );
