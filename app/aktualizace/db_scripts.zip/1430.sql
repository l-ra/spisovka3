
ALTER TABLE [osoba] CHANGE [user_created] [user_created] int(10) unsigned DEFAULT NULL;
