ALTER TABLE [{tbls3}dokument] DROP COLUMN [spisovy_plan];
