INSERT INTO [{tbls3}settings] VALUES ('epodatelna_auto_load_new_messages', 'true');
