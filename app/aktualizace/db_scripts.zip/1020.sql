ALTER TABLE [:PREFIX:spis] DROP COLUMN [datum_otevreni];
