
UPDATE `{tbls3}subjekt` SET stav = 2 WHERE stav <> 1;
