
DELETE FROM [{tbls3}user_resource] WHERE [code] = 'Spisovka_NapovedaPresenter';
