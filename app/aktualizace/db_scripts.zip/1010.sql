DROP TABLE [:PREFIX:dokument_historie];

DROP TABLE [:PREFIX:osoba_historie];

DROP TABLE [:PREFIX:subjekt_historie];
