
UPDATE [spis] SET [orgjednotka_id] = NULL WHERE [typ] = 'F';
