ALTER TABLE [:PREFIX:spis]  ADD INDEX [typ] ([typ]);
