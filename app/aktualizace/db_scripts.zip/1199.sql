
ALTER TABLE [epodatelna]
    CHANGE COLUMN [adresat] [adresat]  varchar(200) NOT NULL DEFAULT '';